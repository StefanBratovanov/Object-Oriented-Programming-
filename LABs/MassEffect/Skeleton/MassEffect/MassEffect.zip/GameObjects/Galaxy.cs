﻿namespace MassEffect.GameObjects
{
    using System.Collections.Generic;
    using System.Linq;
    
    using Exceptions;
    using Locations;
    using Interfaces;

    public class Galaxy
    {
        public HashSet<StarSystem> StarSystems { get; set; }

        public Galaxy()
        {
            this.StarSystems = new HashSet<StarSystem>();
        }

        public StarSystem GetStarSystemByName(string name)
        {
            return this.StarSystems
                .First(s => s.Name == name);
        }

        public void TravelTo(IStarship ship, StarSystem destination)
        {
            var startLocation = ship.Location;
            if (!startLocation.NeighbourStarSystems.ContainsKey(destination))
            {
                throw new LocationOutOfRangeException(string.Format(
                    "Cannot travel directly from {0} to {1}",
                    startLocation.Name, destination.Name));
            }

            double requiredFuel = startLocation.NeighbourStarSystems[destination];
            if (ship.Fuel < requiredFuel)
            {
                throw new InsufficientFuelException(string.Format(
                    "Not enough fuel to travel to {0} - {1}/{2}", 
                    destination.Name, ship.Fuel, requiredFuel));
            }

            ship.Fuel -= requiredFuel;
            ship.Location = destination;
        }
    }
}
